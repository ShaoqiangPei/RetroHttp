# bsdiff-win
[bsdiff](http://www.daemonology.net/bsdiff/) Windows binaries and Visual Studio 2015 project.

> Schwarzer 2018
